import pygame
import os
from TiledObject import TiledObject

class AnimatedTiledObject(TiledObject):
    def __init__(self, screen, frames, pos, animation_speed=10, show_hitbox=False):
        first_frame = frames[0].convert_alpha()
        super().__init__(screen, first_frame, pos, show_hitbox)

        self.frames = frames
        self.current_frame = 0
        self.animation_speed = animation_speed
        self.animation_counter = 0
        self.animating = False

    def animate(self):
        if self.animating:
            self.animation_counter += 1
            if self.animation_counter >= self.animation_speed:
                self.current_frame = (self.current_frame + 1) % len(self.frames)
                self.tile = self.frames[self.current_frame]
                self.animation_counter = 0

    def place(self):
        self.animate()
        super().place()

    # override da funcao de colisao
    def check_collision(self, other_rect):
        if super().check_collision(other_rect):
            self.animating = not self.animating
            return True
        return False
